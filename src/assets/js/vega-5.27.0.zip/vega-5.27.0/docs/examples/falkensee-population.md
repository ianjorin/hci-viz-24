---
layout: example
title: Falkensee Population Example
permalink: /examples/falkensee-population/index.html
spec: falkensee-population
image: /examples/img/falkensee-population.png
---

The population of the German city of Falkensee over time, by Dominik Moritz. Based on an [image from Wikipedia](https://de.wikipedia.org/wiki/Datei:Bev%C3%B6lkerungsentwicklung_Falkensee.pdf).

{% include example spec=page.spec %}
