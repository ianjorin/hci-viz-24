---
layout: example
title: Wheat and Wages Example
permalink: /examples/wheat-and-wages/index.html
spec: wheat-and-wages
image: /examples/img/wheat-and-wages.png
---

A recreation of [William Playfair's](https://en.wikipedia.org/wiki/William_Playfair) classic chart visualizing the price of wheat, the wages of a mechanic, and the reigning British monarch.

{% include example spec=page.spec %}
