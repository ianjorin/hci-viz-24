You can ask questions on [Stack Overflow](https://stackoverflow.com/tags/vega-lite), [the mailing list](https://bit.ly/vega-discuss) or on [Slack](https://bit.ly/join-vega-slack-2022).
